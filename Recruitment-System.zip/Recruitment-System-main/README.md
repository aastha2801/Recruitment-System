# Recruitment System

## A Recruitment System is software for recruiters to track candidates throughout the recruiting and hiring process. It is a software that automates administrative tasks in recruitment and hiring. It enables faster interview scheduling, easier job advertising, optimized referrals, automated processes, and more.

<p> In that, the software includes many functionalities. These functionalities   are: </p>

-	Login through admin. 
-	Easy to manage things. 
-	Upload applicant’s resume.
-	Parse resume successfully.
-	Generate resume score as per qualities of the applicant. 
-	Create jobs specific to domains and requirements. 
-	Schedule interviews. 
-	Send emails and enjoy the hiring process. 

![image](https://user-images.githubusercontent.com/68602671/205838975-8a508820-38db-492c-ae4f-4199ef3c6ac9.png)
![image](https://user-images.githubusercontent.com/68602671/205839037-1f6ecf31-5d0a-43a6-8435-cf8158720a15.png)
![image](https://user-images.githubusercontent.com/68602671/205839160-1acdd30e-5df4-476f-bec7-6fea1fa639e2.png)
![image](https://user-images.githubusercontent.com/68602671/205839207-b9137597-f70b-4de7-8621-64cab0142e25.png)
![image](https://user-images.githubusercontent.com/68602671/205839255-bacd8553-7d89-49bf-84d6-7a959540f87f.png)
![image](https://user-images.githubusercontent.com/68602671/205839282-758da083-52d0-4920-bf6f-5ad0f9ff2da9.png)

